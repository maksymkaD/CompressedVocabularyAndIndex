﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

/*
 * This Pair class is used as a data structure for Vocabulary, has a comparator
 * which compairs first element of a Pair, so it has to be comparable.
 */
public class Pair<T, K> : IComparable<Pair<T, K>> where T : IComparable<T>
{
    private T t;
    private K k;
    public Pair(T t, K k)
    {
        this.t = t;
        this.k = k;
    }

    /*
     * Comparator for Pair (compares only first element)
     * @return Less then zero -> this < other
     *                   Zero -> this == other
     *         More then zeor -> this > other
     */
    public int CompareTo(Pair<T, K> other)
    {
        return this.t.CompareTo(other.t);
    }

    /*
    *Checks if t and k have same type
    * @return true if types are same, else false
    */
    public bool isSameType()
    {
        return t.GetType() == k.GetType();
    }

    /* Change this.t (first element).
     * @param t - element, which will be set at this.t
     */
    public void setFirst(T t)
    {
        this.t = t;
    }

    /* Change this.k (second element).
     * @param k - element, which will be set at this.k
     */
    public void setSecond(K k)
    {
        this.k = k;
    }

    //Returns first element of Pair
    public T first()
    {
        return this.t;
    }

    //Returns second element of Pair
    public K second()
    {
        return this.k;
    }


}



