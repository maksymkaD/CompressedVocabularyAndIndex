﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace CompressedIndex
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] pathArray = new[] {
            //Enter path to file(s) from which you want to compose a vocabulary
            "D:\\avidreaders.ru__animal-farm-a-fairy-story.fb2",
                    "D:\\meta.fb2",
                    /*
                    "D:\\avidreaders.ru__animal-farm-a-fairy-story.fb2",
                    "D:\\meta.fb2",
                    "D:\\books\\Lazareva_Rycar-nochi_1_Rycar-nochi.01wXfg.183834.fb2",
                    "D:\\books\\Mid_Akademiya-Vampirov_1_Ohotniki-i-zhertvy.jvDSmw.518795.fb2",
                    "D:\\books\\Mid_Akademiya-Vampirov_6_Poslednyaya-zhertva.lC66dw.518796.fb2",
                    "D:\\books\\Smit_Dnevniki-vampira_1_Probuzhdenie.-VaMtQ.145204.fb2",
                    "D:\\books\\Usacheva_Plenniki-sumerek_1_Vlechenie.v-i2cg.161778.fb2",
                    */
                };

            string file_content = "";
            HashSet<string> set = new HashSet<string>();
            for (int i = 0; i < pathArray.Length; i++)
            {
                file_content += System.IO.File.ReadAllText(pathArray[i]);
                string[] contentStrs = Regex.Split(file_content, "\\s+<*>\\s+|[^a-zA-Z]+");
                foreach (string str in contentStrs)
                {
                    if (!set.Contains(str)) { set.Add(str); }
                }
            }

            CompressedVocabulary cv = new CompressedVocabulary(4);
            string[] arr = new string[set.Count];
            set.CopyTo(arr);
            cv.Add(arr);
            Console.Write("Enter word: ");
            string query = Console.ReadLine();
            Console.WriteLine(cv.Search(query));
            

        }
               

    }
}
