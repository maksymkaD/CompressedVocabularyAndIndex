﻿using System;
using System.Collections; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompressedReverseIndex
{
    class CompressedReverseIndex
    {
        SortedDictionary<string, SortedSet<uint>> cri = new SortedDictionary<string, SortedSet<uint>>();
        public CompressedReverseIndex()
        {

        }

        public void Add(string word, int docId)
        {
            if(!cri.ContainsKey(word))
            {
                cri.Add(word, new SortedSet<uint>() { (uint)docId });
            }
            if(cri.ContainsKey(word))
            {
                uint sum = 0;
                foreach(uint interval in cri[word])
                {
                    sum += interval;
                }
                cri[word].Add((uint)docId - sum);
            }
        }



    }


}
