﻿using System;
using System.Collections.Generic;
using System.Text;


namespace CompressedIndex
{
    class CompressedVocabulary
    {
        public string[] vocabulary;
        public int BlockLength { get; }
        public CompressedVocabulary(int bl)
        {
            this.BlockLength = bl;
        }

        public void Add(string[] words)
        {
            Array.Sort(words);
            vocabulary = new string[(int)Math.Ceiling((double)words.Length / 4)];
            int blockCount = 0;
            for (int i = 0; i < words.Length; i++)
            {
                vocabulary[blockCount] += words[i].Length + words[i];
                if ((i + 1) % 4 == 0) blockCount++;
            }
        }

        public bool Search(string word)
        {
            int firstIndex = 0;
            int lastIndex = vocabulary.Length - 1;

            // условие прекращения (элемент не представлен)
            while (firstIndex <= lastIndex)
            {
                int middleIndex = (firstIndex + lastIndex) / 2;
                
                string block = vocabulary[middleIndex];
                string first = block.Substring(FindInt(block).ToString().Length, FindInt(block));
                
                if (string.Compare(word, first) == -1)
                {
                    lastIndex = middleIndex - 1;
                }
                else
                {
                    if (first == word) return true;
                    Console.WriteLine(block);
                    block = block.Substring(FindInt(block).ToString().Length+first.Length);
                    for (int i = 0; i < BlockLength - 1; i++)
                    {
                        
                        int length = FindInt(block);
                        string blockElement = block.Substring(FindInt(block).ToString().Length, length);
                        Console.WriteLine(blockElement +" ["+length+"]" + " => " + block);
                        
                        block = block.Substring(length.ToString().Length + blockElement.Length);
                           
                        if (length == word.Length) if (blockElement == word) return true;

                    }
                    firstIndex = middleIndex + 1;

                }
            }
            return false;
        }

        static public int FindInt(string str)
        {
            int result = -1;
            for (int i = 0; i < str.Length; i++)
            {
                try
                {
                    result = Int32.Parse(str.Substring(0, i + 1));
                }
                catch { break; }
            }
            return result;

        }





    }
}
